package com.example.myapplication.ui.home;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.myapplication.MainActivity;
import com.example.myapplication.R;
import com.example.myapplication.databinding.FragmentHomeBinding;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Date;

import me.tankery.lib.circularseekbar.CircularSeekBar;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private EditText integrationInput = null;
    public static LineChart chart = null;
    CircularSeekBar seekBar = null;
    private TextView unitsText = null;
    public static boolean acquiringData = false;
    public static Switch aSwitch;
    public static TextView statusText;
    private Button screenShotButton = null;
    private Button saveDataButton = null;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        return root;
    }

    //Converts a float either from user input or the circular scroll wheel into a valid usable number to send to the Main Activity as a string
    private String convertIntegration(float f) {
        if (f <= 0) { return null; }

        //Minimums and Maximums per setting
        if (unitsMode == 0 && f < 10) { return "10"; }
        if (unitsMode == 2 && f > 50) { return "50"; }
        if (f > 10000)                { return "10000"; }

        //Rounds to 2 sig figs
        if (f > 1000) {
            return "" + Math.round(f / 100)*100;
        } else if (f > 100) {
            return "" + Math.round(f / 10)*10;
        } else if (f >= 10) {
            return "" + Math.round(f);
        } else {
            if (unitsMode == 0) {
                return "" + Math.round(f);
            }
            String s = "" + f;
            if (s.length() > 3) {
                s = s.substring(0, 3);
            }
            return s;
        }
    }
    private int unitsMode = 0;
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (chart == null) {
            setupChart();
        }

        integrationInput = getView().findViewById(R.id.editTextNumberSigned);
        integrationInput.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                // If the event is a key-down event on the "enter" button
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {

                    try {
                        //Converts user input to usable format
                        String sending = convertIntegration(Float.parseFloat(integrationInput.getText().toString()));
                        if (sending == null) {
                            integrationInput.setText("");
                            return true;
                        }
                        //Sets self to the formatted version
                        integrationInput.setText(sending);

                        //updates the circular seekbar to the same number
                        float num = Float.parseFloat(sending);
                        if (seekBar != null) {
                            seekBar.setProgress(num);
                        }
                    } catch (Exception e) {
                        System.out.println("Failure parsing float");
                    }

                    //Sends the integration time to the Main Activity to send the request via bluetooth
                    updateIntegrationTime();
                    return true;
                }
                return false;
            }
        });

        statusText = getView().findViewById(R.id.statusText);

        aSwitch = getView().findViewById(R.id.switch5);
        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                acquiringData = isChecked;
                if (saveDataButton == null || screenShotButton == null) { return; }

                if (isChecked) {
                    saveDataButton.setBackgroundColor(Color.parseColor("#b00505"));
                    screenShotButton.setBackgroundColor(Color.parseColor("#b00505"));
                } else {
                    saveDataButton.setBackgroundColor(Color.GRAY);
                    screenShotButton.setBackgroundColor(Color.GRAY);
                }
            }
        });

        unitsText = getView().findViewById(R.id.unitsText);
        RadioGroup radioGroup = getView().findViewById(R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radioButton5) {

                    if (seekBar != null) { seekBar.setMax(50); }
                    unitsMode = 2;
                    unitsText.setText("s");
                } else {
                    seekBar.setMax(1000);
                }
                if (checkedId == R.id.radioButton4) {
                    unitsMode = 1;
                    unitsText.setText("ms");
                }
                if (checkedId == R.id.radioButton3) {
                    unitsMode = 0;
                    unitsText.setText("μs");
                }

                try {
                    if (seekBar != null) {
                        seekBar.setProgress(unitsMode == 0 ? 10 : 1);
                    }
                    Thread.sleep(10);
                } catch (Exception e) {}
                updateIntegrationTime();

            }
        });

        seekBar = getView().findViewById(R.id.circularSeekBar);
        seekBar.setOnSeekBarChangeListener(new CircularSeekBar.OnCircularSeekBarChangeListener() {
            @Override
            public void onProgressChanged(@Nullable CircularSeekBar circularSeekBar, float v, boolean b) {
                if (v < 1) { v = 1; }

                String s = convertIntegration(v);
                if (s == null) {
                    integrationInput.setText("");
                } else {
                    integrationInput.setText(s);
                }

            }

            @Override
            public void onStopTrackingTouch(@Nullable CircularSeekBar circularSeekBar) {
                updateIntegrationTime();
            }

            @Override
            public void onStartTrackingTouch(@Nullable CircularSeekBar circularSeekBar) {}
        });

        saveDataButton = getView().findViewById(R.id.SaveCSVButton);
        saveDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (acquiringData) {
                    MainActivity.downloading = true;
                }
            }
        });

        screenShotButton = getView().findViewById(R.id.ScreenshotButton);
        screenShotButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (acquiringData) {
                    takeScreenshot();
                }
            }
        });

        saveDataButton.setBackgroundColor(Color.GRAY);
        screenShotButton.setBackgroundColor(Color.GRAY);
    }

    //Sends the new integration time to the Main Activity and confirms that it is in the correct format
    public void updateIntegrationTime() {
        String sending = convertIntegration(Float.parseFloat(integrationInput.getText().toString()));
        if (sending == null) { return; }

        float f = Float.parseFloat(sending);
        if (unitsMode == 1) { f *= 1000; }
        else if (unitsMode == 2) { f *= 1000000; }

        int finalVal = (int)f;
        sending = "e" + finalVal;

        MainActivity.intOld.set(sending);
        MainActivity.intChanged.set(sending);
    }

    public void setupChart() {
        chart = getView().findViewById(R.id.chart_view);
        if (chart == null) {
            System.out.println("Null Chart");
            return;
        }
        chart.setNoDataText("Connecting to CCD... Make sure power is on.");
        chart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        chart.getXAxis().setAxisMinimum(0);
        chart.getXAxis().setAxisMaximum(3600);
        chart.getAxisLeft().setAxisMaximum(1.001f);
        chart.getAxisLeft().setAxisMinimum(0);
        chart.getAxisRight().setEnabled(false);
        chart.setTouchEnabled(true);
        chart.getXAxis().setLabelCount(10, false);
        chart.getAxisLeft().setLabelCount(10, false);
        chart.getDescription().setEnabled(false);
        chart.getLegend().setEnabled(false);

        //IMarker marker = new MyMarkerView(this.getContext(), R.id.theView);
        //chart.setMarker(marker);
    }
    private void scanFile(File f) {
        MediaScannerConnection
                .scanFile(getActivity().getBaseContext(), new String[] {f.getAbsolutePath()},
                        null, null);
    }
    private void takeScreenshot() {
        Date now = new Date();
        android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);

        try {
            // image naming and path  to include sd card  appending name you choose for file
            String mPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString() + "/" + now + ".jpg";

            // create bitmap screen capture
            View v1 = getActivity().getWindow().getDecorView().getRootView();
            v1.setDrawingCacheEnabled(true);
            Bitmap bitmap = Bitmap.createBitmap(v1.getDrawingCache());
            v1.setDrawingCacheEnabled(false);

            File imageFile = new File(mPath);
            scanFile(imageFile);

            FileOutputStream outputStream = new FileOutputStream(imageFile);
            int quality = 100;
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream);
            outputStream.flush();
            outputStream.close();

            openScreenshot(imageFile);
        } catch (Throwable e) {
            // Several error may come out with file handling or DOM
            e.printStackTrace();
        }
    }
    private void openScreenshot(File imageFile) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        Uri uri = Uri.fromFile(imageFile);
        intent.setDataAndType(uri, "image/*");
        startActivity(intent);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        MainActivity.intChanged.set("D");
    }
}