package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.DocumentsContract;
import android.util.Log;
import android.view.Menu;

import com.example.myapplication.ui.home.HomeFragment;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.myapplication.databinding.ActivityMainBinding;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.concurrent.atomic.AtomicReference;

import com.github.mikephil.charting.*;


public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private BluetoothDevice bluetoothDevice = null;
    private BluetoothSocket mBluetoothSocket = null;
    private UpdateGraphThread updateThread = null;
    private Thread bluetoothThread = null;
    public static boolean downloading = false;

    public static AtomicReference<String> intChanged = new AtomicReference<String>("e20");
    public static AtomicReference<String> intOld = new AtomicReference<String>("e20");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        bluetoothThread = new Thread(new ConnectBluetoothCycleThread());
        bluetoothThread.start();
    }

    protected void onStop() {
        super.onStop();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                HomeFragment.aSwitch.setChecked(false);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onPanelClosed(int featureId, @NonNull Menu menu) {
        super.onPanelClosed(featureId, menu);
        intChanged.set("0");
        try {
            if (updateThread != null) {
                updateThread.join(1000);
            }
            if (bluetoothThread != null) {
                bluetoothThread.join(1000);
            }
        } catch (Exception e) {}
    }
    public boolean setupBluetooth() {
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            System.out.println("Bluetooth Adapter Null");
            return false;
        }


        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            //return false;
        }

        ArrayList<BluetoothDevice> spectraMinis = new ArrayList<>();

        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() > 0) {
            // There are paired devices. Get the name and address of each paired device.
            for (BluetoothDevice device : pairedDevices) {
                String deviceName = device.getName();
                String deviceHardwareAddress = device.getAddress(); // MAC address
                //if (deviceName.contains("SpectraMiniCCD")) {
                if (deviceName.contains("SpectraMiniCCD")) {
                    spectraMinis.add(device);
                }
            }
        }

        bluetoothAdapter.cancelDiscovery();
        for (int i = 0; i < spectraMinis.size(); i++) {
            bluetoothDevice = spectraMinis.get(i);
            try {
                mBluetoothSocket = bluetoothDevice.createRfcommSocketToServiceRecord(bluetoothDevice.getUuids()[0].getUuid());
            } catch (Exception e) {
                System.out.println(e);
                continue;
            }

            try {
                mBluetoothSocket.connect();
            } catch (Exception e) {
                System.out.println("Failed to connect | isConn: " + mBluetoothSocket.isConnected());
                System.out.println(e);
                continue;
            }

            System.out.println("Connected");
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    HomeFragment.statusText.setText("Connected");
                }
            });
            return true;
        }
        return false;
    }

    void flushInputStream(InputStream in) {
        try{
            int readN = in.available();
            while (readN != 0) {
                byte[] garbBuff = new byte[readN];
                int read = in.read(garbBuff, 0, readN);
                System.out.println("Avail: " + readN + ", flushed: " + read);
                Thread.sleep(100);
                readN = in.available();
            }
        } catch (Exception e) {}
    }
    public void graphNothing(String str) {
        try {
            if (HomeFragment.chart != null) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        HomeFragment.chart.setNoDataText(str);
                        HomeFragment.chart.clear();
                        HomeFragment.chart.postInvalidate();
                    }
                });
            }
        } catch (Exception e) {
            System.out.println("Chart was null in thread...");
        }
    }
    public class ConnectBluetoothCycleThread implements Runnable {
        int cycles = 0;

        public void run() {
            System.out.println("Started Connect");
            graphNothing("Connecting to CCD... Make sure power is on.");

            while (!setupBluetooth() && !intChanged.get().equals("0")) {
                try { Thread.sleep(1000); } catch (Exception e) {}

                if (cycles > 1) {
                    graphNothing("Is the CCD Powered? Try Unplugging and plugging it back in again.");
                }
                cycles++;
            }

            if (!intChanged.get().equals("0")) {
                intChanged.set(intOld.get());
                updateThread = new UpdateGraphThread();
                updateThread.start();
            }
        }
    }
    public class UpdateGraphThread extends Thread {
        private final int numData = 3694 * 2;
        public AtomicReference<Uri> pickedFile = new AtomicReference(null);
        private byte[] mmBuffer = new byte[numData];
        private long deltaTime = 0L;
        private int cdAfterChangeIntegration = 0;
        private OutputStream out = null;
        private InputStream in = null;
        public UpdateGraphThread() {}

        public void run() {
            System.out.println("Began Thread");
            try {
                out = mBluetoothSocket.getOutputStream();
                in =  mBluetoothSocket.getInputStream();

                Thread.sleep(200);
            } catch (Exception e) {}

            flushInputStream(in);

            while (mBluetoothSocket != null && mBluetoothSocket.isConnected() && intChanged.get().length() != 1) {
                flushInputStream(in);

                final String integrationTime = intChanged.get();
                if (integrationTime.length() > 1) {
                    sendIntChangeRequest(integrationTime);
                    intChanged.set("");
                }

                flushInputStream(in);

                if (HomeFragment.chart == null || !HomeFragment.acquiringData) {
                    graphNothing("Ready to start!");
                    try {
                        Thread.sleep(500);
                        sendSleeping();  //Polls bluetooth to identify if connection is lost
                    } catch (Exception e) {}
                    continue;
                }
                deltaTime = System.nanoTime();

                sendDataRequest();
                gatherData();

                deltaTime = System.nanoTime() - deltaTime;
                System.out.println("Time: " + deltaTime/1000000 + "ms | fps: " + (1000000000.0/deltaTime)); //Benchmark the time for a response

                flushInputStream(in);

                if (HomeFragment.chart != null) {
                    if (cdAfterChangeIntegration <= 0) {
                        graphData();
                    } else {
                        graphNothing("Changing integration time...");
                        cdAfterChangeIntegration--;
                    }
                }
            }

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    HomeFragment.statusText.setText("Disconnected");
                }
            });
            System.out.println("Closed Thread");

            if (!intChanged.get().equals("0")) {
                bluetoothThread = new Thread(new ConnectBluetoothCycleThread());
                bluetoothThread.start();
            }
        }
        public void sendIntChangeRequest(final String s) {
            try {
                String send = s;
                while (send.length() < 20) {
                    send += '\0';
                }
                out.write(send.getBytes(StandardCharsets.UTF_8));
                System.out.println("Wrote Integration: " + s);
                cdAfterChangeIntegration = 1;
                graphNothing("Changing integration time...");
            } catch (Exception e) {
                System.out.println("Integration Data Send Request Failed");
                requestStop();
            }
        }
        public void requestStop() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    HomeFragment.aSwitch.setChecked(false);
                }
            });
            intChanged.set("1");
        }
        public void sendSleeping() {
            try {
                String s = "z";
                while (s.length() < 20) {
                    s += '\0';
                }
                out.write(s.getBytes(StandardCharsets.UTF_8));
            } catch (Exception e) {
                System.out.println("Send Sleep Failed");
                requestStop();
            }
        }
        public void sendDataRequest() {
            try {
                String s = "s";
                while (s.length() < 20) {
                    s += '\0';
                }
                out.write(s.getBytes(StandardCharsets.UTF_8));
            } catch (Exception e) {
                System.out.println("Data Send Request Failed");
                requestStop();
            }
        }

        public void gatherData() {
            System.out.print("Start Read\t");
            try {
                for (int i = 0; i < numData; i++) {
                    int c = in.read();
                    if (i == 0 ) { System.out.print("Read First\t"); }
                    if (c == -1) {
                        System.out.println("End Of Stream Hit");
                        break;
                    }
                    mmBuffer[i] = (byte)c;
                }

            } catch (Exception e) {
                System.out.println("Data Gather Failed");
                System.out.println(e);
                //try{ mBluetoothSocket.close(); Thread.sleep(500); } catch (Exception e2) {}
                //finishAndRemoveTask();
                requestStop();
            }
            System.out.print("End Read\t");

        }
        public void graphData() {
            String csvData = "Pixel,Value\n";

            boolean downing = downloading;

            LineDataSet lineDataSet = new LineDataSet(null, null);

            for (int i = 40*2; i < 3680*2-1; i += 2) {


long num = 3150 - (
                        ((mmBuffer[i+1] & 255) << 8) + (mmBuffer[i] & 255)
                );
           float insert = num/2200.0f;
                if (insert >= 1) {
                    insert = 1;
                }
                insert -= 0.12;
                insert *= 1.2;

                if (insert > 1) {
                    //System.out.println("Invalid Data recorded: " + num);
                    insert = 0.995f;
                }
                if (insert < 0) {
                    insert = 0.005f;
                }

                lineDataSet.addEntry(new Entry(i/2 - 40, insert));
                if (downing) {
                    csvData += (i/2 - 39) + "," + insert + "\n";
                }


       /*         long num = 3350 - (
                        ((mmBuffer[i+1] & 255) << 8) + (mmBuffer[i] & 255)
                );
                float insert = num/4000.0f;
                insert *= 1.67f;
                if (insert >= 1) {
                    insert = 0.995f;
                }
                if (insert <= 0.005f) {
                    insert = 0.005f;
                }

                lineDataSet.addEntry(new Entry(i/2 - 40, insert));
                if (downing) {
                    csvData += (i/2 - 39) + "," + insert + "\n";
                }

        */
            }


            lineDataSet.setColor(Color.DKGRAY);
            lineDataSet.setLineWidth(1.8f);
            lineDataSet.setColor(Color.rgb(180, 0, 0));
            lineDataSet.setDrawCircleHole(false);
            lineDataSet.setDrawCircles(false);
            //lineDataSet.setCircleRadius(1);

            lineDataSet.setValueTextSize(0);
            lineDataSet.setDrawFilled(false);
            lineDataSet.setFormLineWidth(1f);

            LineData data = new LineData(lineDataSet);

            try {
                if (HomeFragment.chart != null) {
                    HomeFragment.chart.setData(data);
                    HomeFragment.chart.postInvalidate();
                }
            } catch (Exception e) {
                System.out.println("Chart was null in thread...");
            }

            if (downing) {
                writeToFile(csvData);
                downloading = false;
            }
        }

        // Request code for creating a PDF document.
        private static final int CREATE_FILE = 1;

        private void createFile(Uri pickerInitialUri) {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("text/csv");
            intent.putExtra(Intent.EXTRA_TITLE, makeFileName());

            // Optionally, specify a URI for the directory that should be opened in
            // the system file picker when your app creates the document.
            //intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, pickerInitialUri);
            //intent, CREATE_FILE

            startActivityForResult(intent, CREATE_FILE);
        }


        private void scanFile(File f) {
            MediaScannerConnection
                    .scanFile(getBaseContext(), new String[] {f.getAbsolutePath()},
                            null, null);
        }
        private String makeFileName() {
            String timeStamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
            return "CCDLineread" + timeStamp + ".csv";
        }
        private File createFileInDocuments() {
            //Checking the availability state of the External Storage.
            String state = Environment.getExternalStorageState();
            if (!Environment.MEDIA_MOUNTED.equals(state)) {
                //If it isn't mounted - we can't write into it.
                System.out.println("MEDIA NOT MOUNTED!");
                return null;
            }

            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
            try {
                path.mkdirs();
                File file = new File(path, makeFileName());
                file.createNewFile();
                scanFile(file);
                return file;
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println(e);
            }
            return null;
        }
        private void writeToFile(String csv) {
            String textToWrite = csv;

            try {
                pickedFile.set(null);
                createFile(null);
                while (pickedFile.get() == null) { Thread.sleep(10); }

                OutputStream outputStream = getContentResolver().openOutputStream(pickedFile.get());

                pickedFile.set(null);



                //FileOutputStream outputStream = new FileOutputStream(file, false);
                outputStream.write(textToWrite.getBytes());
                outputStream.flush();
                outputStream.close();
                System.out.println("Wrote File");
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println(e);
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode,
                                 Intent resultData) {
        super.onActivityResult(requestCode, resultCode, resultData);

        if (requestCode == UpdateGraphThread.CREATE_FILE
                && resultCode == Activity.RESULT_OK) {
            // The result data contains a URI for the document or directory that
            // the user selected.
            Uri uri = null;
            if (resultData != null) {
                uri = resultData.getData();
                // Perform operations on the document using its URI.
                updateThread.pickedFile.set(uri);
            }
        }
    }
}

